//
//  ContentView.swift
//  PassData
//
//  Created by Ahmed Salah on 18/08/2022.
//

import SwiftUI

struct ContentView: View {
    
    var data : [Data] = DataList.topTen
    
    var body: some View {
        
        NavigationView{
            List(data, id: \.id){ data in
                NavigationLink(destination: DataView(data2: data)) {
                    HStack{
                        Image(data.Img)
                            .resizable()
                            .scaleEffect()
                            .frame(width: 80 ,height: 80)
                            .cornerRadius(4)
                            .padding(.vertical , 4)
                        
                        VStack(alignment: .leading, spacing: 5){
                            Text(data.Name)
                                .fontWeight(.semibold)
                                .lineLimit(2)
                                .minimumScaleFactor(0.5)
                            
                            Text(data.Des2)
                                .font(.system(size: 15))
                                .foregroundColor(.secondary)
                        }
                    }
                }
                
            }
            .navigationTitle("Coffee")
        }
        
    }
}










struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
