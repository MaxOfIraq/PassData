//
//  Data.swift
//  PassData
//
//  Created by Ahmed Salah on 20/08/2022.
//

import SwiftUI

struct Data : Identifiable{
    
    let id = UUID()
    let Name : String
    let Img : String
    let Des : String
    let Des2 : String
}


struct DataList {
    
    static let topTen = [
        
        Data(Name: "Coffee 1", Img: "icon1", Des: "this is best coffee", Des2: "this is best coffeethis is best coffee"),
        
        
        Data(Name: "Coffee 2", Img: "icon2", Des: "this is best coffee", Des2: "this is best coffeethis is best coffee"),
        
        
        
        Data(Name: "Coffee 3", Img: "icon3", Des: "this is best coffee", Des2: "this is best coffeethis is best coffee")
        
        
        ]
    
    
    
}
