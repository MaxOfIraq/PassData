//
//  PassDataApp.swift
//  PassData
//
//  Created by Ahmed Salah on 18/08/2022.
//

import SwiftUI

@main
struct ProjectApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
