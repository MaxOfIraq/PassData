//
//  DataView.swift
//  PassData
//
//  Created by Ahmed Salah on 20/08/2022.
//

import SwiftUI

struct DataView : View {
    
    var data2 : Data
    
    var body: some View {
        VStack(spacing: 20){
            
            
            Image(data2.Img)
                .resizable()
                .scaledToFit()
                .frame(height: 150)
                .cornerRadius(12)
            
            Text(data2.Name)
                .font(.title2)
                .fontWeight(.semibold)
                .lineLimit(2)
                .multilineTextAlignment(.center)
                .padding(.horizontal)
            

            Text(data2.Des)
                .font(.body)
                .padding()
            
            Spacer()
            
            
        }.navigationBarTitle("Deatls Coffee")
    }
}

struct DataView_Previews: PreviewProvider {
    static var previews: some View {
        DataView(data2: DataList.topTen.first!)
    }
}
